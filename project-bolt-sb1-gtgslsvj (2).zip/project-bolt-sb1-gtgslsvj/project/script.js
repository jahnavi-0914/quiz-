// Enhanced Quiz data with different question types and difficulties
const quizData = {
  general: [
    {
      question: "What is the capital of Australia?",
      type: "multiple-choice",
      difficulty: "easy",
      options: ["Sydney", "Melbourne", "Canberra", "Perth"],
      correct: 2,
      explanation: "Canberra is the capital city of Australia, despite Sydney and Melbourne being larger cities. It was chosen as a compromise between the two rival cities and became the capital in 1913.",
      hint: "It's not the largest city in Australia.",
      image: null
    },
    {
      question: "The Great Wall of China is visible from space.",
      type: "true-false",
      difficulty: "medium",
      options: ["True", "False"],
      correct: 1,
      explanation: "This is a common myth. The Great Wall of China is not visible from space with the naked eye. This misconception has been debunked by astronauts and space agencies.",
      hint: "This is actually a popular misconception.",
      image: null
    },
    {
      question: "Fill in the blank: The largest ocean on Earth is the _____ Ocean.",
      type: "fill-blank",
      difficulty: "easy",
      correctAnswer: "Pacific",
      explanation: "The Pacific Ocean is the largest ocean, covering about 63 million square miles and containing more than half of the free water on Earth.",
      hint: "It means 'peaceful' in Latin.",
      image: null
    },
    {
      question: "Who painted the Mona Lisa?",
      type: "multiple-choice",
      difficulty: "easy",
      options: ["Vincent van Gogh", "Leonardo da Vinci", "Pablo Picasso", "Michelangelo"],
      correct: 1,
      explanation: "Leonardo da Vinci painted the Mona Lisa between 1503 and 1519. It's housed in the Louvre Museum in Paris and is considered one of the most famous paintings in the world.",
      hint: "He was also an inventor and scientist during the Renaissance.",
      image: null
    },
    {
      question: "What is the hardest natural substance on Earth?",
      type: "multiple-choice",
      difficulty: "medium",
      options: ["Gold", "Iron", "Diamond", "Quartz"],
      correct: 2,
      explanation: "Diamond is the hardest natural substance, rating 10 on the Mohs hardness scale. This hardness comes from its crystal structure where carbon atoms are arranged in a strong lattice.",
      hint: "It's often used in engagement rings and industrial cutting tools.",
      image: null
    },
    {
      question: "Mount Everest is located in which mountain range?",
      type: "multiple-choice",
      difficulty: "medium",
      options: ["Andes", "Rocky Mountains", "Himalayas", "Alps"],
      correct: 2,
      explanation: "Mount Everest is located in the Himalayas on the border between Nepal and Tibet. At 29,032 feet (8,849 meters), it's the highest mountain above sea level.",
      hint: "This mountain range is in Asia and contains the world's highest peaks.",
      image: null
    },
    {
      question: "The human body has 206 bones.",
      type: "true-false",
      difficulty: "medium",
      options: ["True", "False"],
      correct: 0,
      explanation: "True! An adult human body has 206 bones. Babies are born with about 270 bones, but many of these fuse together as they grow and develop.",
      hint: "This number is for adults - babies actually have more bones that fuse over time.",
      image: null
    },
    {
      question: "What is the chemical symbol for gold?",
      type: "multiple-choice",
      difficulty: "hard",
      options: ["Go", "Gd", "Au", "Ag"],
      correct: 2,
      explanation: "Au is the chemical symbol for gold, derived from the Latin word 'aurum' meaning 'shining dawn'. Gold has been valued by humans for thousands of years.",
      hint: "It comes from a Latin word meaning 'shining dawn'.",
      image: null
    },
    {
      question: "Fill in the blank: World War II ended in the year _____.",
      type: "fill-blank",
      difficulty: "medium",
      correctAnswer: "1945",
      explanation: "World War II ended in 1945 with the surrender of Japan in September, following the atomic bombings of Hiroshima and Nagasaki and the Soviet invasion of Manchuria.",
      hint: "It's the same year the atomic bombs were dropped on Japan.",
      image: null
    },
    {
      question: "The Amazon rainforest produces 20% of the world's oxygen.",
      type: "true-false",
      difficulty: "hard",
      options: ["True", "False"],
      correct: 1,
      explanation: "False. While the Amazon is crucial for global climate, it produces about 6% of the world's oxygen. Most oxygen comes from phytoplankton in the oceans. However, the Amazon does absorb significant amounts of CO2.",
      hint: "The actual percentage is much lower than commonly believed.",
      image: null
    }
  ],
  english: [
    {
      question: "What is the plural of 'child'?",
      type: "multiple-choice",
      difficulty: "easy",
      options: ["Childs", "Children", "Childes", "Child"],
      correct: 1,
      explanation: "Children is the irregular plural form of child. English has many irregular plurals that don't follow the standard 's' or 'es' rule, such as children, feet, teeth, and mice.",
      hint: "It's an irregular plural form that doesn't follow normal rules.",
      image: null
    },
    {
      question: "'Their' and 'there' have the same meaning.",
      type: "true-false",
      difficulty: "easy",
      options: ["True", "False"],
      correct: 1,
      explanation: "False. 'Their' is a possessive pronoun (their house), while 'there' indicates a place or position (over there). These are homophones - words that sound the same but have different meanings.",
      hint: "These words sound the same but mean different things.",
      image: null
    },
    {
      question: "Fill in the blank: The past tense of 'go' is _____.",
      type: "fill-blank",
      difficulty: "easy",
      correctAnswer: "went",
      explanation: "Went is the past tense of go, while gone is the past participle. This is an irregular verb that doesn't follow the standard '-ed' pattern for past tense formation.",
      hint: "It's an irregular verb form that doesn't end in '-ed'.",
      image: null
    },
    {
      question: "Which sentence is grammatically correct?",
      type: "multiple-choice",
      difficulty: "medium",
      options: ["I have less books than you", "I have fewer books than you", "I have lesser books than you", "I have few books than you"],
      correct: 1,
      explanation: "Use 'fewer' with countable nouns like books, and 'less' with uncountable nouns like water or time. This is a common grammar rule that many native speakers get wrong.",
      hint: "Use this word with countable nouns, the other with uncountable nouns.",
      image: null
    },
    {
      question: "What type of word is 'quickly'?",
      type: "multiple-choice",
      difficulty: "medium",
      options: ["Noun", "Verb", "Adjective", "Adverb"],
      correct: 3,
      explanation: "Quickly is an adverb because it describes how an action is performed. Adverbs often end in '-ly' and modify verbs, adjectives, or other adverbs.",
      hint: "It describes how something is done and often ends in '-ly'.",
      image: null
    },
    {
      question: "Shakespeare wrote 37 plays.",
      type: "true-false",
      difficulty: "hard",
      options: ["True", "False"],
      correct: 0,
      explanation: "True. William Shakespeare wrote approximately 37 plays during his career, including famous works like Hamlet, Romeo and Juliet, Macbeth, and A Midsummer Night's Dream.",
      hint: "This is the generally accepted number by most scholars.",
      image: null
    },
    {
      question: "What is the opposite of 'ancient'?",
      type: "multiple-choice",
      difficulty: "easy",
      options: ["Old", "Modern", "Historic", "Traditional"],
      correct: 1,
      explanation: "Modern is the opposite of ancient, referring to present or recent times. Ancient refers to very old times, typically thousands of years ago.",
      hint: "It refers to current or recent times.",
      image: null
    },
    {
      question: "Fill in the blank: A group of lions is called a _____.",
      type: "fill-blank",
      difficulty: "medium",
      correctAnswer: "pride",
      explanation: "A group of lions is called a pride. Different animals have unique collective nouns - a flock of birds, a school of fish, a pack of wolves, etc.",
      hint: "It's also an emotion meaning self-respect or satisfaction.",
      image: null
    },
    {
      question: "Which word is spelled correctly?",
      type: "multiple-choice",
      difficulty: "medium",
      options: ["Recieve", "Receive", "Receve", "Receeve"],
      correct: 1,
      explanation: "Receive follows the rule 'i before e except after c'. This spelling rule helps with many English words, though there are exceptions like 'weird' and 'seize'.",
      hint: "Remember: 'i before e except after c'.",
      image: null
    },
    {
      question: "A metaphor directly compares two things using 'like' or 'as'.",
      type: "true-false",
      difficulty: "hard",
      options: ["True", "False"],
      correct: 1,
      explanation: "False. A metaphor directly compares two things without using 'like' or 'as' (e.g., 'Life is a journey'). A simile uses 'like' or 'as' for comparison (e.g., 'Life is like a journey').",
      hint: "You're thinking of a different literary device that uses 'like' or 'as'.",
      image: null
    }
  ],
  math: [
    {
      question: "What is 15% of 200?",
      type: "multiple-choice",
      difficulty: "easy",
      options: ["25", "30", "35", "40"],
      correct: 1,
      explanation: "15% of 200 = 0.15 × 200 = 30. To find a percentage of a number, convert the percentage to a decimal by dividing by 100, then multiply.",
      hint: "Convert the percentage to a decimal first (15% = 0.15).",
      image: null
    },
    {
      question: "The square root of 144 is 12.",
      type: "true-false",
      difficulty: "easy",
      options: ["True", "False"],
      correct: 0,
      explanation: "True. √144 = 12 because 12 × 12 = 144. Perfect squares like 144 have whole number square roots.",
      hint: "Think of which number multiplied by itself gives 144.",
      image: null
    },
    {
      question: "Fill in the blank: If x + 5 = 12, then x = _____.",
      type: "fill-blank",
      difficulty: "easy",
      correctAnswer: "7",
      explanation: "x + 5 = 12, so x = 12 - 5 = 7. To solve for x, subtract 5 from both sides of the equation.",
      hint: "Subtract 5 from both sides of the equation.",
      image: null
    },
    {
      question: "What is the area of a circle with radius 5?",
      type: "multiple-choice",
      difficulty: "medium",
      options: ["25π", "10π", "5π", "50π"],
      correct: 0,
      explanation: "Area of circle = πr² = π × 5² = 25π. The area formula uses the radius squared, not just the radius.",
      hint: "Remember the formula: πr² (pi times radius squared).",
      image: null
    },
    {
      question: "What is 2³ + 3²?",
      type: "multiple-choice",
      difficulty: "medium",
      options: ["13", "17", "19", "23"],
      correct: 1,
      explanation: "2³ = 8 and 3² = 9, so 8 + 9 = 17. Remember that exponents are calculated before addition according to the order of operations.",
      hint: "Calculate each exponent separately first: 2³ = 8, 3² = 9.",
      image: null
    },
    {
      question: "All triangles have angles that sum to 180°.",
      type: "true-false",
      difficulty: "medium",
      options: ["True", "False"],
      correct: 0,
      explanation: "True. The sum of interior angles in any triangle is always 180°. This is a fundamental property of triangles in Euclidean geometry.",
      hint: "This is a fundamental property of all triangles.",
      image: null
    },
    {
      question: "What is the slope of the line y = 3x + 2?",
      type: "multiple-choice",
      difficulty: "hard",
      options: ["2", "3", "5", "-3"],
      correct: 1,
      explanation: "In the equation y = mx + b, m is the slope and b is the y-intercept. So the slope is 3, and the y-intercept is 2.",
      hint: "Look at the coefficient of x in the equation y = mx + b.",
      image: null
    },
    {
      question: "Fill in the blank: 7! (7 factorial) equals _____.",
      type: "fill-blank",
      difficulty: "hard",
      correctAnswer: "5040",
      explanation: "7! = 7 × 6 × 5 × 4 × 3 × 2 × 1 = 5040. Factorial means multiplying all positive integers from 1 up to that number.",
      hint: "Multiply all positive integers from 1 to 7: 7×6×5×4×3×2×1.",
      image: null
    },
    {
      question: "If log₁₀(x) = 2, what is x?",
      type: "multiple-choice",
      difficulty: "hard",
      options: ["10", "20", "100", "1000"],
      correct: 2,
      explanation: "If log₁₀(x) = 2, then x = 10² = 100. Logarithms and exponents are inverse operations.",
      hint: "What power of 10 equals x? If log₁₀(x) = 2, then 10² = x.",
      image: null
    },
    {
      question: "The derivative of x² is 2x.",
      type: "true-false",
      difficulty: "hard",
      options: ["True", "False"],
      correct: 0,
      explanation: "True. The derivative of x² is 2x using the power rule: bring down the exponent and reduce it by 1. So d/dx(x²) = 2x¹ = 2x.",
      hint: "Use the power rule: bring down the exponent and reduce it by 1.",
      image: null
    }
  ],
  programming: [
    {
      question: "What does HTML stand for?",
      type: "multiple-choice",
      difficulty: "easy",
      options: ["High Tech Modern Language", "HyperText Markup Language", "Home Tool Markup Language", "Hyperlink and Text Markup Language"],
      correct: 1,
      explanation: "HTML stands for HyperText Markup Language. It's used for creating the structure and content of web pages using elements and tags.",
      hint: "It's used for web page structure and contains the word 'Markup'.",
      image: null
    },
    {
      question: "Python is a compiled programming language.",
      type: "true-false",
      difficulty: "medium",
      options: ["True", "False"],
      correct: 1,
      explanation: "False. Python is an interpreted language, not compiled. The Python interpreter reads and executes code line by line, though it does compile to bytecode internally.",
      hint: "Think about how Python code is executed - does it need to be compiled first?",
      image: null
    },
    {
      question: "Fill in the blank: The time complexity of binary search is O(_____)",
      type: "fill-blank",
      difficulty: "medium",
      correctAnswer: "log n",
      explanation: "Binary search has O(log n) time complexity because it halves the search space with each iteration. This makes it very efficient for searching sorted arrays.",
      hint: "It divides the problem in half each time - think logarithmic.",
      image: null
    },
    {
      question: "In JavaScript, what does '===' check for?",
      type: "multiple-choice",
      difficulty: "medium",
      options: ["Equality only", "Type only", "Both equality and type", "Neither equality nor type"],
      correct: 2,
      explanation: "The === operator checks for both value equality and type equality (strict equality). For example, 5 === '5' returns false because they're different types.",
      hint: "It's stricter than the == operator and checks two things.",
      image: null
    },
    {
      question: "What is a 'bug' in programming?",
      type: "multiple-choice",
      difficulty: "easy",
      options: ["A feature", "An error or defect", "A comment", "A variable"],
      correct: 1,
      explanation: "A bug is an error, flaw, or defect in a computer program that causes incorrect or unexpected results. The term originated from actual insects found in early computer hardware.",
      hint: "It's something you don't want in your code that causes problems.",
      image: null
    },
    {
      question: "A stack follows the FIFO (First In, First Out) principle.",
      type: "true-false",
      difficulty: "medium",
      options: ["True", "False"],
      correct: 1,
      explanation: "False. A stack follows LIFO (Last In, First Out) principle. FIFO is the principle followed by queues. Think of a stack of plates - you take from the top.",
      hint: "Think of a stack of plates - which one do you take first?",
      image: null
    },
    {
      question: "Fill in the blank: API stands for Application _____ Interface.",
      type: "fill-blank",
      difficulty: "easy",
      correctAnswer: "Programming",
      explanation: "API stands for Application Programming Interface. It allows different software components to communicate with each other by defining methods of communication.",
      hint: "It's related to writing code and making different programs work together.",
      image: null
    },
    {
      question: "In Python, which symbol is used for comments?",
      type: "multiple-choice",
      difficulty: "easy",
      options: ["//", "/*", "#", "<!--"],
      correct: 2,
      explanation: "In Python, the # symbol is used for single-line comments. Multi-line comments can use triple quotes (''' or \"\"\").",
      hint: "It's also called the hash symbol or pound sign.",
      image: null
    },
    {
      question: "What is the output of '5' + 3 in JavaScript?",
      type: "multiple-choice",
      difficulty: "hard",
      options: ["8", "53", "Error", "undefined"],
      correct: 1,
      explanation: "JavaScript converts the number 3 to string and concatenates, resulting in '53'. This is because the + operator performs string concatenation when one operand is a string.",
      hint: "JavaScript performs string concatenation, not mathematical addition.",
      image: null
    },
    {
      question: "Git is a version control system.",
      type: "true-false",
      difficulty: "easy",
      options: ["True", "False"],
      correct: 0,
      explanation: "True. Git is a distributed version control system used to track changes in source code during software development. It helps developers collaborate and manage code history.",
      hint: "It helps developers track changes and collaborate on code.",
      image: null
    }
  ]
};

// User management system
let currentUser = {
  name: 'Guest User',
  email: 'guest@example.com',
  isGuest: true,
  totalScore: 0,
  quizzesCompleted: 0,
  badges: [],
  history: [],
  rank: '-'
};

// Game state
let currentCategory = '';
let currentDifficulty = 'easy';
let currentQuestionIndex = 0;
let score = 0;
let timeLeft = 30;
let timer = null;
let startTime = null;
let userAnswers = [];
let lifelines = {
  fiftyFifty: true,
  skip: true,
  extraTime: true,
  hint: true,
  audiencePoll: true
};

// Leaderboard data (simulated)
let leaderboardData = {
  overall: [
    { name: 'Alice Johnson', score: 850, quizzes: 25 },
    { name: 'Bob Smith', score: 720, quizzes: 18 },
    { name: 'Carol Davis', score: 680, quizzes: 22 },
    { name: 'David Wilson', score: 650, quizzes: 15 },
    { name: 'Emma Brown', score: 620, quizzes: 20 }
  ],
  general: [
    { name: 'Alice Johnson', score: 95, quizzes: 8 },
    { name: 'Bob Smith', score: 88, quizzes: 6 },
    { name: 'Carol Davis', score: 82, quizzes: 7 }
  ],
  english: [
    { name: 'Emma Brown', score: 92, quizzes: 5 },
    { name: 'David Wilson', score: 85, quizzes: 4 },
    { name: 'Alice Johnson', score: 78, quizzes: 3 }
  ],
  math: [
    { name: 'Carol Davis', score: 96, quizzes: 8 },
    { name: 'Bob Smith', score: 89, quizzes: 7 },
    { name: 'Alice Johnson', score: 84, quizzes: 6 }
  ],
  programming: [
    { name: 'David Wilson', score: 94, quizzes: 6 },
    { name: 'Bob Smith', score: 87, quizzes: 5 },
    { name: 'Emma Brown', score: 81, quizzes: 4 }
  ]
};

// Available badges
const badges = [
  { id: 'first_quiz', name: 'First Steps', icon: '🎯', description: 'Complete your first quiz' },
  { id: 'perfect_score', name: 'Perfect Score', icon: '🏆', description: 'Get 100% on any quiz' },
  { id: 'speed_demon', name: 'Speed Demon', icon: '⚡', description: 'Complete a quiz in under 5 minutes' },
  { id: 'scholar', name: 'Scholar', icon: '🎓', description: 'Complete 10 quizzes' },
  { id: 'master', name: 'Quiz Master', icon: '👑', description: 'Complete 25 quizzes' },
  { id: 'streak', name: 'On Fire', icon: '🔥', description: 'Get 5 questions right in a row' }
];

// Comments system (simulated)
let comments = [];

// DOM elements
const pages = {
  auth: document.getElementById('auth-page'),
  home: document.getElementById('home-page'),
  quiz: document.getElementById('quiz-page'),
  results: document.getElementById('results-page'),
  review: document.getElementById('review-page'),
  profile: document.getElementById('profile-page'),
  leaderboard: document.getElementById('leaderboard-page')
};

// Initialize the app
document.addEventListener('DOMContentLoaded', function() {
  initializeEventListeners();
  loadUserData();
  showPage('auth');
});

function initializeEventListeners() {
  // Auth tabs
  document.querySelectorAll('.auth-tab').forEach(tab => {
    tab.addEventListener('click', function() {
      switchAuthTab(this.dataset.tab);
    });
  });

  // Category selection
  document.querySelectorAll('.category-card').forEach(card => {
    card.addEventListener('click', function() {
      const category = this.dataset.category;
      showDifficultySelection(category);
    });
  });

  // Quiz controls
  document.querySelectorAll('.option').forEach(option => {
    option.addEventListener('click', function() {
      if (!this.classList.contains('disabled')) {
        selectAnswer(parseInt(this.dataset.option));
      }
    });
  });

  // Lifelines
  document.getElementById('fifty-fifty').addEventListener('click', useFiftyFifty);
  document.getElementById('skip-question').addEventListener('click', skipQuestion);
  document.getElementById('extra-time').addEventListener('click', useExtraTime);
  document.getElementById('hint').addEventListener('click', useHint);
  document.getElementById('audience-poll').addEventListener('click', useAudiencePoll);

  // Navigation
  document.getElementById('next-question').addEventListener('click', nextQuestion);
  document.getElementById('play-again').addEventListener('click', () => startQuiz(currentCategory, currentDifficulty));
  document.getElementById('home-btn').addEventListener('click', () => showPage('home'));
  document.getElementById('review-answers').addEventListener('click', showReview);
  document.getElementById('back-to-results').addEventListener('click', () => showPage('results'));
  document.getElementById('generate-certificate').addEventListener('click', generateCertificate);
  document.getElementById('share-results').addEventListener('click', shareResults);
}

// Authentication functions
function switchAuthTab(tab) {
  document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.auth-form').forEach(f => f.classList.remove('active'));
  
  document.querySelector(`[data-tab="${tab}"]`).classList.add('active');
  document.getElementById(`${tab}-form`).classList.add('active');
}

function login() {
  const email = document.getElementById('login-email').value;
  const password = document.getElementById('login-password').value;
  
  if (!email || !password) {
    alert('Please fill in all fields');
    return;
  }
  
  // Simulate login (in real app, this would be an API call)
  currentUser = {
    name: email.split('@')[0],
    email: email,
    isGuest: false,
    totalScore: Math.floor(Math.random() * 1000),
    quizzesCompleted: Math.floor(Math.random() * 20),
    badges: ['first_quiz', 'scholar'],
    history: [],
    rank: Math.floor(Math.random() * 100) + 1
  };
  
  saveUserData();
  showPage('home');
  updateUserInterface();
}

function register() {
  const name = document.getElementById('register-name').value;
  const email = document.getElementById('register-email').value;
  const password = document.getElementById('register-password').value;
  const confirmPassword = document.getElementById('register-confirm').value;
  
  if (!name || !email || !password || !confirmPassword) {
    alert('Please fill in all fields');
    return;
  }
  
  if (password !== confirmPassword) {
    alert('Passwords do not match');
    return;
  }
  
  // Simulate registration
  currentUser = {
    name: name,
    email: email,
    isGuest: false,
    totalScore: 0,
    quizzesCompleted: 0,
    badges: [],
    history: [],
    rank: '-'
  };
  
  saveUserData();
  showPage('home');
  updateUserInterface();
}

function socialLogin(provider) {
  // Simulate social login
  currentUser = {
    name: `${provider} User`,
    email: `user@${provider}.com`,
    isGuest: false,
    totalScore: Math.floor(Math.random() * 500),
    quizzesCompleted: Math.floor(Math.random() * 10),
    badges: ['first_quiz'],
    history: [],
    rank: Math.floor(Math.random() * 200) + 1
  };
  
  saveUserData();
  showPage('home');
  updateUserInterface();
}

function enterGuestMode() {
  currentUser = {
    name: 'Guest User',
    email: 'guest@example.com',
    isGuest: true,
    totalScore: 0,
    quizzesCompleted: 0,
    badges: [],
    history: [],
    rank: '-'
  };
  
  showPage('home');
  updateUserInterface();
}

function logout() {
  currentUser = {
    name: 'Guest User',
    email: 'guest@example.com',
    isGuest: true,
    totalScore: 0,
    quizzesCompleted: 0,
    badges: [],
    history: [],
    rank: '-'
  };
  
  localStorage.removeItem('quizUserData');
  showPage('auth');
}

// User data management
function saveUserData() {
  if (!currentUser.isGuest) {
    localStorage.setItem('quizUserData', JSON.stringify(currentUser));
  }
}

function loadUserData() {
  const savedData = localStorage.getItem('quizUserData');
  if (savedData) {
    currentUser = JSON.parse(savedData);
  }
}

function updateUserInterface() {
  document.getElementById('user-name').textContent = currentUser.name;
  document.getElementById('total-score').textContent = currentUser.totalScore;
  document.getElementById('quizzes-completed').textContent = currentUser.quizzesCompleted;
  document.getElementById('user-rank').textContent = currentUser.rank;
}

function showPage(pageName) {
  Object.values(pages).forEach(page => page.classList.remove('active'));
  pages[pageName].classList.add('active');
  
  if (pageName === 'home') {
    updateUserInterface();
  }
}

function showDifficultySelection(category) {
  const difficulties = ['easy', 'medium', 'hard'];
  const choice = prompt(`Choose difficulty for ${category}:\n1. Easy\n2. Medium\n3. Hard\n\nEnter 1, 2, or 3:`);
  
  let difficulty = 'easy';
  if (choice === '2') difficulty = 'medium';
  else if (choice === '3') difficulty = 'hard';
  
  startQuiz(category, difficulty);
}

function startQuiz(category, difficulty = 'easy') {
  currentCategory = category;
  currentDifficulty = difficulty;
  currentQuestionIndex = 0;
  score = 0;
  userAnswers = [];
  startTime = Date.now();
  
  // Reset lifelines
  lifelines = {
    fiftyFifty: true,
    skip: true,
    extraTime: true,
    hint: true,
    audiencePoll: true
  };

  updateLifelinesUI();
  
  // Filter questions by difficulty
  const allQuestions = quizData[category];
  const filteredQuestions = allQuestions.filter(q => q.difficulty === difficulty);
  
  if (filteredQuestions.length === 0) {
    alert('No questions available for this difficulty level');
    return;
  }
  
  // Randomize questions
  quizData[category] = shuffleArray(filteredQuestions).slice(0, 10);
  
  // Update category title
  document.getElementById('quiz-category').textContent = 
    `${category.charAt(0).toUpperCase() + category.slice(1)} - ${difficulty.charAt(0).toUpperCase() + difficulty.slice(1)}`;
  document.getElementById('difficulty-level').textContent = difficulty.charAt(0).toUpperCase() + difficulty.slice(1);
  
  showPage('quiz');
  loadQuestion();
}

function startDailyChallenge() {
  // Mix questions from all categories for daily challenge
  const allQuestions = [];
  Object.keys(quizData).forEach(category => {
    allQuestions.push(...quizData[category].slice(0, 3));
  });
  
  const dailyQuestions = shuffleArray(allQuestions).slice(0, 10);
  
  currentCategory = 'daily';
  currentDifficulty = 'mixed';
  quizData.daily = dailyQuestions;
  
  startQuiz('daily', 'mixed');
}

function shuffleArray(array) {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}

function loadQuestion() {
  const questions = quizData[currentCategory];
  const question = questions[currentQuestionIndex];
  
  // Update question counter and progress
  document.getElementById('question-counter').textContent = `${currentQuestionIndex + 1}/${questions.length}`;
  document.getElementById('progress-fill').style.width = `${((currentQuestionIndex + 1) / questions.length) * 100}%`;
  document.getElementById('score').textContent = `Score: ${score}`;
  
  // Load question
  document.getElementById('question-text').textContent = question.question;
  
  // Handle different question types
  const optionsContainer = document.getElementById('options-container');
  const fillBlankContainer = document.getElementById('fill-blank-container');
  const questionImage = document.getElementById('question-image');
  
  // Hide all containers first
  optionsContainer.classList.remove('hidden');
  fillBlankContainer.classList.add('hidden');
  questionImage.classList.add('hidden');
  
  // Show image if available
  if (question.image) {
    questionImage.innerHTML = `<img src="${question.image}" alt="Question image">`;
    questionImage.classList.remove('hidden');
  }
  
  if (question.type === 'fill-blank') {
    optionsContainer.classList.add('hidden');
    fillBlankContainer.classList.remove('hidden');
    document.getElementById('fill-blank-input').value = '';
  } else {
    // Handle multiple choice and true/false
    const options = document.querySelectorAll('.option');
    
    if (question.type === 'true-false') {
      options[0].textContent = 'True';
      options[1].textContent = 'False';
      options[2].style.display = 'none';
      options[3].style.display = 'none';
    } else {
      options.forEach((option, index) => {
        if (index < question.options.length) {
          option.textContent = question.options[index];
          option.style.display = 'block';
        } else {
          option.style.display = 'none';
        }
      });
    }
    
    options.forEach(option => {
      option.className = 'option';
    });
  }
  
  // Hide feedback and other boxes
  document.getElementById('feedback-box').classList.add('hidden');
  document.getElementById('hint-box').classList.add('hidden');
  document.getElementById('audience-poll-box').classList.add('hidden');
  document.getElementById('next-question').classList.add('hidden');
  
  // Start timer
  startTimer();
}

function submitFillBlank() {
  const userInput = document.getElementById('fill-blank-input').value.trim().toLowerCase();
  const question = quizData[currentCategory][currentQuestionIndex];
  const correctAnswer = question.correctAnswer.toLowerCase();
  
  clearInterval(timer);
  
  const isCorrect = userInput === correctAnswer;
  if (isCorrect) {
    score++;
  }
  
  // Store user answer
  userAnswers.push({
    question: question.question,
    type: question.type,
    userAnswer: userInput,
    correctAnswer: question.correctAnswer,
    isCorrect: isCorrect,
    explanation: question.explanation
  });
  
  showFeedback(isCorrect, question.explanation);
  document.getElementById('next-question').classList.remove('hidden');
}

function selectAnswer(selectedIndex) {
  clearInterval(timer);
  
  const questions = quizData[currentCategory];
  const question = questions[currentQuestionIndex];
  const options = document.querySelectorAll('.option');
  
  // Disable all options
  options.forEach(option => option.classList.add('disabled'));
  
  // Mark selected option
  options[selectedIndex].classList.add('selected');
  
  // Show correct/incorrect
  const isCorrect = selectedIndex === question.correct;
  if (isCorrect) {
    score++;
    options[selectedIndex].classList.add('correct');
  } else {
    options[selectedIndex].classList.add('incorrect');
    options[question.correct].classList.add('correct');
  }
  
  // Store user answer
  userAnswers.push({
    question: question.question,
    type: question.type,
    options: question.options,
    userAnswer: selectedIndex,
    correctAnswer: question.correct,
    isCorrect: isCorrect,
    explanation: question.explanation
  });
  
  showFeedback(isCorrect, question.explanation);
  document.getElementById('next-question').classList.remove('hidden');
}

function showFeedback(isCorrect, explanation) {
  const feedbackBox = document.getElementById('feedback-box');
  const feedbackIcon = document.getElementById('feedback-icon');
  const feedbackTitle = document.getElementById('feedback-title');
  const feedbackExplanation = document.getElementById('feedback-explanation');
  
  feedbackBox.classList.remove('hidden', 'correct', 'incorrect');
  
  if (isCorrect) {
    feedbackBox.classList.add('correct');
    feedbackIcon.textContent = '✅';
    feedbackTitle.textContent = 'Correct!';
  } else {
    feedbackBox.classList.add('incorrect');
    feedbackIcon.textContent = '❌';
    feedbackTitle.textContent = 'Incorrect';
  }
  
  feedbackExplanation.textContent = explanation;
}

function startTimer() {
  timeLeft = 30;
  updateTimer();
  
  timer = setInterval(() => {
    timeLeft--;
    updateTimer();
    
    if (timeLeft <= 0) {
      clearInterval(timer);
      timeUp();
    }
  }, 1000);
}

function updateTimer() {
  const timerElement = document.getElementById('timer');
  timerElement.textContent = `${timeLeft}s`;
  
  if (timeLeft <= 10) {
    timerElement.classList.add('timer-warning');
  } else {
    timerElement.classList.remove('timer-warning');
  }
}

function timeUp() {
  const questions = quizData[currentCategory];
  const question = questions[currentQuestionIndex];
  
  if (question.type === 'fill-blank') {
    // Handle fill-blank timeout
    userAnswers.push({
      question: question.question,
      type: question.type,
      userAnswer: 'No answer (Time up)',
      correctAnswer: question.correctAnswer,
      isCorrect: false,
      explanation: question.explanation
    });
  } else {
    // Handle multiple choice timeout
    const options = document.querySelectorAll('.option');
    options.forEach(option => option.classList.add('disabled'));
    options[question.correct].classList.add('correct');
    
    userAnswers.push({
      question: question.question,
      type: question.type,
      options: question.options,
      userAnswer: -1,
      correctAnswer: question.correct,
      isCorrect: false,
      explanation: question.explanation
    });
  }
  
  showFeedback(false, question.explanation);
  document.getElementById('next-question').classList.remove('hidden');
}

function nextQuestion() {
  currentQuestionIndex++;
  
  if (currentQuestionIndex >= quizData[currentCategory].length) {
    showResults();
  } else {
    loadQuestion();
  }
}

function showResults() {
  const totalQuestions = quizData[currentCategory].length;
  const accuracy = Math.round((score / totalQuestions) * 100);
  const timeTaken = Math.round((Date.now() - startTime) / 1000);
  const xpEarned = score * 10 + (accuracy >= 80 ? 50 : 0);
  
  // Update user stats
  currentUser.totalScore += score * 10;
  currentUser.quizzesCompleted++;
  
  // Add to history
  currentUser.history.unshift({
    category: currentCategory,
    difficulty: currentDifficulty,
    score: score,
    total: totalQuestions,
    accuracy: accuracy,
    date: new Date().toLocaleDateString(),
    timeTaken: timeTaken
  });
  
  // Check for new badges
  const newBadges = checkForNewBadges(accuracy, timeTaken);
  
  // Update UI
  document.getElementById('final-score').textContent = score;
  document.getElementById('correct-count').textContent = score;
  document.getElementById('accuracy').textContent = `${accuracy}%`;
  document.getElementById('time-taken').textContent = `${timeTaken}s`;
  document.getElementById('xp-earned').textContent = xpEarned;
  
  // Show new badges
  const badgesContainer = document.getElementById('badges-earned');
  if (newBadges.length > 0) {
    badgesContainer.innerHTML = '<h4>🎉 New Badges Earned!</h4>' + 
      newBadges.map(badge => `<span class="badge-item">${badge.icon} ${badge.name}</span>`).join('');
  } else {
    badgesContainer.innerHTML = '';
  }
  
  // Results message
  let message = '';
  if (accuracy >= 90) {
    message = 'Outstanding! You\'re a quiz master! 🏆';
  } else if (accuracy >= 80) {
    message = 'Excellent work! Great knowledge! 🌟';
  } else if (accuracy >= 70) {
    message = 'Good job! Room for improvement. 👍';
  } else if (accuracy >= 60) {
    message = 'Not bad! Keep studying! 📚';
  } else {
    message = 'Keep practicing! You\'ll get better! 💪';
  }
  
  document.getElementById('results-message').textContent = message;
  
  saveUserData();
  showPage('results');
}

function checkForNewBadges(accuracy, timeTaken) {
  const newBadges = [];
  
  // First quiz badge
  if (currentUser.quizzesCompleted === 1 && !currentUser.badges.includes('first_quiz')) {
    currentUser.badges.push('first_quiz');
    newBadges.push(badges.find(b => b.id === 'first_quiz'));
  }
  
  // Perfect score badge
  if (accuracy === 100 && !currentUser.badges.includes('perfect_score')) {
    currentUser.badges.push('perfect_score');
    newBadges.push(badges.find(b => b.id === 'perfect_score'));
  }
  
  // Speed demon badge
  if (timeTaken < 300 && !currentUser.badges.includes('speed_demon')) {
    currentUser.badges.push('speed_demon');
    newBadges.push(badges.find(b => b.id === 'speed_demon'));
  }
  
  // Scholar badge
  if (currentUser.quizzesCompleted >= 10 && !currentUser.badges.includes('scholar')) {
    currentUser.badges.push('scholar');
    newBadges.push(badges.find(b => b.id === 'scholar'));
  }
  
  // Master badge
  if (currentUser.quizzesCompleted >= 25 && !currentUser.badges.includes('master')) {
    currentUser.badges.push('master');
    newBadges.push(badges.find(b => b.id === 'master'));
  }
  
  return newBadges;
}

function showReview() {
  const reviewContent = document.getElementById('review-content');
  reviewContent.innerHTML = '';
  
  userAnswers.forEach((answer, index) => {
    const questionDiv = document.createElement('div');
    questionDiv.className = 'review-question';
    
    let optionsHTML = '';
    let userAnswerText = '';
    let correctAnswerText = '';
    
    if (answer.type === 'fill-blank') {
      userAnswerText = answer.userAnswer;
      correctAnswerText = answer.correctAnswer;
    } else {
      optionsHTML = answer.options.map((option, optIndex) => {
        let className = 'review-option';
        if (optIndex === answer.correctAnswer && answer.userAnswer === answer.correctAnswer) {
          className += ' user-correct';
        } else if (optIndex === answer.correctAnswer) {
          className += ' correct-answer';
        } else if (optIndex === answer.userAnswer) {
          className += ' user-answer';
        }
        
        return `<div class="${className}">${String.fromCharCode(65 + optIndex)}. ${option}</div>`;
      }).join('');
      
      userAnswerText = answer.userAnswer === -1 ? 'No answer (Time up)' : 
                     answer.userAnswer === -2 ? 'Skipped' :
                     answer.options[answer.userAnswer];
      correctAnswerText = answer.options[answer.correctAnswer];
    }
    
    questionDiv.innerHTML = `
      <h4>Question ${index + 1}: ${answer.question}</h4>
      ${optionsHTML ? `<div class="review-options">${optionsHTML}</div>` : ''}
      <p><strong>Your Answer:</strong> ${userAnswerText}</p>
      <p><strong>Correct Answer:</strong> ${correctAnswerText}</p>
      <div class="explanation">
        <strong>Explanation:</strong> ${answer.explanation}
      </div>
    `;
    
    reviewContent.appendChild(questionDiv);
  });
  
  loadComments();
  showPage('review');
}

function loadComments() {
  const commentsContainer = document.getElementById('comments-container');
  commentsContainer.innerHTML = '';
  
  comments.forEach(comment => {
    const commentDiv = document.createElement('div');
    commentDiv.className = 'comment';
    commentDiv.innerHTML = `
      <div class="comment-author">${comment.author}</div>
      <div class="comment-text">${comment.text}</div>
    `;
    commentsContainer.appendChild(commentDiv);
  });
}

function addComment() {
  const commentText = document.getElementById('comment-text').value.trim();
  if (!commentText) return;
  
  comments.push({
    author: currentUser.name,
    text: commentText,
    date: new Date().toISOString()
  });
  
  document.getElementById('comment-text').value = '';
  loadComments();
}

function saveQuiz() {
  const quizState = {
    category: currentCategory,
    difficulty: currentDifficulty,
    questionIndex: currentQuestionIndex,
    score: score,
    userAnswers: userAnswers,
    lifelines: lifelines
  };
  
  localStorage.setItem('savedQuiz', JSON.stringify(quizState));
  alert('Quiz saved! You can resume it later from the home page.');
}

function showProfile() {
  // Update profile information
  document.getElementById('profile-name').textContent = currentUser.name;
  document.getElementById('profile-email').textContent = currentUser.email;
  document.getElementById('profile-initial').textContent = currentUser.name.charAt(0).toUpperCase();
  document.getElementById('profile-total-score').textContent = currentUser.totalScore;
  document.getElementById('profile-quizzes').textContent = currentUser.quizzesCompleted;
  document.getElementById('profile-rank').textContent = currentUser.rank;
  
  // Show badges
  const badgesGrid = document.getElementById('user-badges');
  badgesGrid.innerHTML = '';
  
  badges.forEach(badge => {
    const badgeDiv = document.createElement('div');
    badgeDiv.className = `badge-card ${currentUser.badges.includes(badge.id) ? 'earned' : ''}`;
    badgeDiv.innerHTML = `
      <div class="badge-icon">${badge.icon}</div>
      <div class="badge-name">${badge.name}</div>
    `;
    badgesGrid.appendChild(badgeDiv);
  });
  
  // Show quiz history
  const historyList = document.getElementById('quiz-history-list');
  historyList.innerHTML = '';
  
  currentUser.history.slice(0, 10).forEach(quiz => {
    const historyDiv = document.createElement('div');
    historyDiv.className = 'history-item';
    historyDiv.innerHTML = `
      <div class="history-info">
        <h4>${quiz.category.charAt(0).toUpperCase() + quiz.category.slice(1)} - ${quiz.difficulty}</h4>
        <p>${quiz.date} • ${quiz.timeTaken}s • ${quiz.accuracy}% accuracy</p>
      </div>
      <div class="history-score">${quiz.score}/${quiz.total}</div>
    `;
    historyList.appendChild(historyDiv);
  });
  
  showPage('profile');
}

function showLeaderboard(category = 'overall') {
  // Update tab buttons
  document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
  event.target.classList.add('active');
  
  const leaderboardContent = document.getElementById('leaderboard-content');
  leaderboardContent.innerHTML = '';
  
  const data = leaderboardData[category] || [];
  
  data.forEach((user, index) => {
    const itemDiv = document.createElement('div');
    itemDiv.className = 'leaderboard-item';
    
    let rankClass = '';
    if (index === 0) rankClass = 'gold';
    else if (index === 1) rankClass = 'silver';
    else if (index === 2) rankClass = 'bronze';
    
    itemDiv.innerHTML = `
      <div class="rank ${rankClass}">${index + 1}</div>
      <div class="user-info">
        <h4>${user.name}</h4>
        <p>${user.quizzes} quizzes completed</p>
      </div>
      <div class="user-score">${user.score}</div>
    `;
    
    leaderboardContent.appendChild(itemDiv);
  });
  
  showPage('leaderboard');
}

function generateCertificate() {
  const modal = document.getElementById('certificate-modal');
  document.getElementById('cert-name').textContent = currentUser.name;
  document.getElementById('cert-quiz').textContent = `${currentCategory.charAt(0).toUpperCase() + currentCategory.slice(1)} Quiz`;
  document.getElementById('cert-score').textContent = score;
  document.getElementById('cert-date').textContent = new Date().toLocaleDateString();
  
  modal.classList.remove('hidden');
}

function closeCertificate() {
  document.getElementById('certificate-modal').classList.add('hidden');
}

function downloadCertificate() {
  alert('Certificate download feature would be implemented with a PDF generation library in a real application.');
}

function shareResults() {
  const shareText = `I just scored ${score}/10 on the ${currentCategory} quiz! Can you beat my score? 🎯`;
  
  if (navigator.share) {
    navigator.share({
      title: 'QuizMaster Pro Results',
      text: shareText,
      url: window.location.href
    });
  } else {
    // Fallback for browsers that don't support Web Share API
    navigator.clipboard.writeText(shareText).then(() => {
      alert('Results copied to clipboard! Share it with your friends!');
    });
  }
}

// Lifeline functions
function useFiftyFifty() {
  if (!lifelines.fiftyFifty) return;
  
  lifelines.fiftyFifty = false;
  document.getElementById('fifty-fifty').classList.add('used');
  
  const questions = quizData[currentCategory];
  const question = questions[currentQuestionIndex];
  
  if (question.type === 'multiple-choice') {
    const options = document.querySelectorAll('.option');
    let hiddenCount = 0;
    
    options.forEach((option, index) => {
      if (index !== question.correct && hiddenCount < 2 && option.style.display !== 'none') {
        option.classList.add('hidden');
        hiddenCount++;
      }
    });
  }
}

function skipQuestion() {
  if (!lifelines.skip) return;
  
  lifelines.skip = false;
  document.getElementById('skip-question').classList.add('used');
  
  clearInterval(timer);
  
  const questions = quizData[currentCategory];
  const question = questions[currentQuestionIndex];
  
  userAnswers.push({
    question: question.question,
    type: question.type,
    options: question.options || [],
    userAnswer: -2, // Skipped
    correctAnswer: question.correct || question.correctAnswer,
    isCorrect: false,
    explanation: question.explanation
  });
  
  nextQuestion();
}

function useExtraTime() {
  if (!lifelines.extraTime) return;
  
  lifelines.extraTime = false;
  document.getElementById('extra-time').classList.add('used');
  
  timeLeft += 15;
  updateTimer();
}

function useHint() {
  if (!lifelines.hint) return;
  
  lifelines.hint = false;
  document.getElementById('hint').classList.add('used');
  
  const questions = quizData[currentCategory];
  const question = questions[currentQuestionIndex];
  
  document.getElementById('hint-text').textContent = question.hint;
  document.getElementById('hint-box').classList.remove('hidden');
}

function useAudiencePoll() {
  if (!lifelines.audiencePoll) return;
  
  lifelines.audiencePoll = false;
  document.getElementById('audience-poll').classList.add('used');
  
  const questions = quizData[currentCategory];
  const question = questions[currentQuestionIndex];
  
  if (question.type !== 'multiple-choice' && question.type !== 'true-false') {
    alert('Audience poll is only available for multiple choice questions');
    return;
  }
  
  // Generate random poll results with bias towards correct answer
  const numOptions = question.type === 'true-false' ? 2 : question.options.length;
  const percentages = new Array(numOptions).fill(0);
  let remaining = 100;
  
  // Give correct answer higher chance (40-70%)
  percentages[question.correct] = 40 + Math.random() * 30;
  remaining -= percentages[question.correct];
  
  // Distribute remaining among other options
  for (let i = 0; i < numOptions; i++) {
    if (i !== question.correct && remaining > 0) {
      const max = remaining / (numOptions - 1);
      percentages[i] = Math.random() * max;
      remaining -= percentages[i];
    }
  }
  
  // Normalize to 100%
  const sum = percentages.reduce((a, b) => a + b, 0);
  percentages.forEach((percent, index) => {
    percentages[index] = Math.round((percent / sum) * 100);
  });
  
  // Update UI
  const pollElements = ['poll-a', 'poll-b', 'poll-c', 'poll-d'];
  const pollPercentElements = ['poll-percent-a', 'poll-percent-b', 'poll-percent-c', 'poll-percent-d'];
  
  pollElements.forEach((id, index) => {
    if (index < numOptions) {
      document.getElementById(id).style.width = `${percentages[index]}%`;
      document.getElementById(pollPercentElements[index]).textContent = `${percentages[index]}%`;
    }
  });
  
  document.getElementById('audience-poll-box').classList.remove('hidden');
}

function updateLifelinesUI() {
  Object.keys(lifelines).forEach(lifeline => {
    const elementId = lifeline === 'fiftyFifty' ? 'fifty-fifty' : 
                     lifeline === 'skip' ? 'skip-question' :
                     lifeline === 'extraTime' ? 'extra-time' :
                     lifeline === 'audiencePoll' ? 'audience-poll' : lifeline;
    
    const element = document.getElementById(elementId);
    if (element) {
      element.classList.toggle('used', !lifelines[lifeline]);
    }
  });
}